/**
 * 
 */
/**
 * 
 */
module atu.software {
	requires javafx.base;
	requires transitive javafx.graphics;
	requires javafx.controls;
	
	exports ie.atu.sw;
}