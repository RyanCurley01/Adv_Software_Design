package ie.atu.sw;

public enum Status {
	Luxury, Premium, Economy, Basic, Steerage;
}
