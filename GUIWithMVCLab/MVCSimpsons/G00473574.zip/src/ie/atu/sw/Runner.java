package ie.atu.sw;

import javafx.application.*;
import javafx.stage.Stage;

public class Runner extends Application {
	
	public static void main(String[] args) {
		System.out.println("[INFO] Launching GUI...");
		Application.launch(AppWindow.class, args);
	}

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
